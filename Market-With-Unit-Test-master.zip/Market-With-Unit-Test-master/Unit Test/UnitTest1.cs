﻿using System;
using Market.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Market.Entities;
using Market.Entities.Entity;

namespace Unit_Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
       public void ItemTest()
       {
            using (var session = NhibernateHelper.OpenSession())
            {
                using (var transaction = session.BeginTransaction())
                {
                    Item item = new Item 
                    { 
                        Name = "Book" , 
                        Unit = Unit.Number
                    };

                    session.Save(item);
                    transaction.Commit();

                    var res = session.Get<Item>(item.Id);
                    Assert.AreEqual(item.Name, res.Name);
                }
            }
        }
        public Guid GetItemId()
        {
            using(var session = NhibernateHelper.OpenSession())
            {
                using(var transaction = session.BeginTransaction())
                {
                    Item item = new Item
                    {
                        Name = "Book",
                        Unit = Unit.Number
                    };

                    session.Save(item);
                    transaction.Commit();

                    item = session.Get<Item>(item.Id);
                    return item.Id;
                }
            }
        }


        [TestMethod]
        public void PurchaseOrderItemTest()
        {
            using (var session = NhibernateHelper.OpenSession())
            {
                using (var transaction = session.BeginTransaction())
                {
                    PurchaseOrderItem purchaseOrderItem = new PurchaseOrderItem
                    {
                        NetPrice = 30 ,
                        Quantity = 900 ,
                        
                    };
                }
            }
        }

        [TestMethod]
        public void RackTest()
        {
            using (var session = NhibernateHelper.OpenSession())
            {
                using (var transaction = session.BeginTransaction())
                {
                    var rack = new Rack
                    {
                        Name = "First",
                        Code = 10,
                        Limit = 700,
                        Location = "First Flat"
                    };

                    session.Save(rack);
                    transaction.Commit();

                    var res = session.Get<Rack>(rack.Id);
                    Assert.AreEqual(rack.Limit, res.Limit);
                }
            }
        }
        /*[TestMethod]
        public void ItemTest
        {
            Rack rack = new Rack { Location = "Tehran" , Name = "First"};
            RackItemLevel rackItemLevel = new RackItemLevel { CurrentQuantity = 80, Item = item , Rack = rack};
            rack.Racks.Add(rack);

            PurchaseOrder purchaseOrder = new PurchaseOrder { Title = "Sale", Code = 10, CreationDate = "2018.10.15" };
            PurchaseOrderItem purchaseOrderItem = new PurchaseOrderItem { NetPrice = 20 };
            purchaseOrder.PurchaseOrderItem.Add(purchaseOrderItem);

            session.Save(item);
            session.Save(purchaseOrder);
            session.Save(rack);
            session.Save(rackItemLevel);
            
            transaction.Commit();

            Assert.AreEqual(purchaseOrder.PurchaseOrderItem.Count, 1);

            var res1 = session.Get<Item>(item.Id);
            Assert.AreEqual(item.Id, res1.Id);

            var res2 = session.Get<PurchaseOrder>(purchaseOrder.Id);
            Assert.AreEqual(purchaseOrder.CreationDate, res2.CreationDate);

            var res3 = session.Get<PurchaseOrderItem>(purchaseOrderItem.Id);
            Assert.AreEqual(purchaseOrderItem.NetPrice, res3.NetPrice);
        }*/
    }
}
